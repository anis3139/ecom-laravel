@extends('layout.app')
@section('title','About')
@section('content')
    <!-- Hero Section Begin -->
    @include('shop-component.Hero')

 
    <!-- Contact Form End -->
@endsection

@section('script')

<script>







</script>

@endsection