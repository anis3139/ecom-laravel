<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">

  <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <?php if( $slider->id==1){
    ?>
     <div class="carousel-item active">
        <img class="d-block w-100" src="<?php echo e($slider->image); ?>">
     <!-- <div class="carousel-caption d-none d-md-block">
         <h5 class="text-light"><?php echo e($slider->title); ?></h5>
           <p class="text-light"><?php echo e($slider->sub_title); ?></p>
      </div> -->
  </div>  <?php
  }else{ ?>
  <div class="carousel-item ">
        <img class="d-block w-100" src="<?php echo e($slider->image); ?>">
     <!-- <div class="carousel-caption d-none d-md-block ">
         <h5 class="text-light"><?php echo e($slider->title); ?></h5>
           <p class="text-light"><?php echo e($slider->sub_title); ?></p>
      </div> -->
  </div> 
<?php } ?> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div><?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-laravel\site\resources\views/component/slider.blade.php ENDPATH**/ ?>