<header class="header">
    <div class="header__top">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="header__top__left">
                        <ul>
                            <li><i class="fa fa-envelope"></i><?php if ($othersData) {
                                                                    echo $othersData->email;
                                                                } ?></li>
                            <li><?php if ($othersData) {
                                    echo $othersData->title;
                                } ?></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="header__top__right">
                        <div class="header__top__right__social">
                            <a href="<?php if ($socialData) {
                                            echo $socialData->facebook;
                                        } ?>"><i class="fa fa-facebook"></i></a>
                            <a href="<?php if ($socialData) {
                                            echo $socialData->instragram;
                                        } ?>"><i class="fa fa-instagram"></i></a>
                            <a href="<?php if ($socialData) {
                                            echo $socialData->twitter;
                                        } ?>"><i class="fa fa-twitter"></i></a>
                            <a href="<?php if ($socialData) {
                                            echo $socialData->youtube;
                                        } ?>"><i class="fa fa-youtube"></i></a>
                        </div>
                        <div class="header__top__right__language">
                            
                          
                                <p className="mt-1" id="google_translate_element"></p>
                           
                        </div>
                        <div class="header__top__right__auth">
                            <?php if($message = Session::get('user')): ?>
                            <a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-user"></i> Log Out</a>
                            <?php else: ?>
                            <a href="<?php echo e(url('/login')); ?>"><i class="fa fa-user"></i> Login</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div style="width: 120px; height:80px" class="header__logo">
                    <a href="./"><img src="<?php if ($othersData) {
                                                echo $othersData->logo;
                                            } ?>" alt=""></a>
                </div>
            </div>
            <div class="col-lg-6">
                <nav class="header__menu">
                    <ul>
                        <li class="active"><a href="/">Home</a></li>
                        <li><a href="./shop">Shop</a></li>
                      
                     
                        <?php if(Session::get('userid')): ?>
                        <li><a href="<?php echo e(url('orderlist')); ?>">Order</a></li>
                        <?php endif; ?>

                        <li><a href="/about">About Us</a></li>
                        
                        <li><a href="/contact">Contact</a></li>
                    </ul>
                </nav>
            </div>


            <div class="col-lg-3">
                <div class="header__cart">
                    <ul>
                        <!-- <li><a href="#"><i class="fa fa-heart"></i> <span></span></a></li> -->
                        <li><a href="<?php echo e(route('cart.list')); ?>"> <i class="fa fa-shopping-bag"></i> <span id="total_product"> </span></a></li>
                    </ul>
                    <div class="header__cart__price">Total: <span id="total_price"></span></div>
                </div>
            </div>
        </div>
        <div class="humberger__open">
            <i class="fa fa-bars"></i>
        </div>
    </div>
</header><?php /**PATH C:\Users\Windows 10\Documents\GitHub\ecom-laravel\site\resources\views/layout/header.blade.php ENDPATH**/ ?>