<?php $__env->startSection('title','About'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Hero Section Begin -->
    <?php echo $__env->make('shop-component.Hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 
    <!-- Contact Form End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>







</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/asulsisc/public_html/resources/views/About.blade.php ENDPATH**/ ?>