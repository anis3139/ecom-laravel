<section class="categories">
        <div class="container">
            <div class="row">
                <div class="categories__slider owl-carousel">
                    <?php $__currentLoopData = $feature_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3">
                        <div class="categories__item set-bg" data-setbg="<?php echo e($feature_product->images); ?>">
                            
                            <h5><a href="<?php echo e(route('product.view', $feature_product->slug)); ?>"><?php echo e($feature_product->title); ?></a></h5>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section><?php /**PATH /home/asulsisc/public_html/resources/views/component/Feature.blade.php ENDPATH**/ ?>